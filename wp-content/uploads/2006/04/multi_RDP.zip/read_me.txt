Windows XP Multiuser Remote Desktop

Remote Desktop ConnectionAn interesting feature, on Windows XP, is the ability to be remote controlled from a second PC: the so called �Remote Desktop Connection� can be used from a dial-up connection or in a local ethernet network.

XP (and Media Center Edition), differently than the Server versions of Windows, has a limit: a single PC can be controlled by a single �local� user (the �real� person on place), OR a single �remote� user. If someone logs into the computer from remote, the local user is disconnected. The following procedure deactivates this block and allows multiple persons to connect and to use a single computer from remote.
Very useful, for example, if you�ve a very strong PC and you want your wife/friend/brother to use an old computer like a �terminal� to use applications on the new one, at the same time of you. Other application of the same technique: you�re at work and you want to connect to your home PC, without blocking your wife that is using the same computer to check email ;)

UPDATE: it seems that XP is limited, also after this modification, to 3 concurrent users. So don�t waste time trying to raise the maximum number of connections over three (see step 5) because, at this time, I don�t think there�s a way to use the same XP PC with more than 3 persons at the same time (e.g. a local user and 2 remote users).

This procedure is an �hack�: do it at your own risk:

STEP 1
Start your Windows in Safe Mode (tap on F8 first of the Windows Loading Splash Screen);
click on �My Computer� with right mouse button and choose �Properties�;
go to �Remote� tab and uncheck �Allow users to connect remotely to this computer� (if it�s already unchecked, just do nothing);
click OK.

STEP 2
Go to Start -> Control Panel;
open �Administrative Tools� and then �Services�;
double click �Terminal Services�, in the list;
choose �Disabled� for �Startup Type� option;
click OK.

STEP 3
Go to C:\windows\system32\dllcache;
rename the termsrv.dll file to termsrv.original or another name you like;
copy into the folder this unrestricted old version of termsrv.dll;
go to C:\windows\system32 (the upper folder of the current one);
do the same operation: rename termserv.dll also here, and put another copy of the file I linked above.

STEP 4
Click Start, then �Run��, type �regedit� (without quotes) and press ENTER;
navigate in the Windows Registry Tree to reach this path:
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\Licensing Core;
click with right mouse button on blank space in the right part of the registry window, choose �New� > DWORD, name the new key �EnableConcurrentSessions� (without quotes), then edit it and set its value to 1;
close the editor.

STEP 5
Click Start, then �Run��, type �gpedit.msc� (without quotes) and press ENTER;
open Computer Configuration > Administrative Templates > Windows Components > Terminal Services;
double click �Limit number of connections�, choose �Enabled� and set the maximum number of concurrent connections you want to allow (2 or more), then Restart Windows in normal mode.

STEP 6
Go back to Remote tab of My Computer�s properties (see step 1) and activate �Allow users to connect remotely to this computer�;
Go back to �Terminal services� in �Services� (see step 2) and set its �Startup type� to �Manual�

Now restart Windows. Your operating system should be ready to accept multiple remote desktop connections ;)
Remember that you�ve to prepare different Windows Users for every �phisical� user that want to connect to your desktop, to autenticate with separate logins/passwords. User accounts configuration is reachable in the control panel, and the list of users that can connect to the PC is editable in the remote tab of My computer.